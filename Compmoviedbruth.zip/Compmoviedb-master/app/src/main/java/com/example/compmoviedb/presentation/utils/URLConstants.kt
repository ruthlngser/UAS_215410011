package com.example.compmoviedb.presentation.utils

object URLConstants {
    const val MOVIEDB_BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500"
}