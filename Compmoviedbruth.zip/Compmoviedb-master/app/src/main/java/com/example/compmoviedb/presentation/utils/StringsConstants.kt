package com.example.compmoviedb.presentation.utils

object StringsConstants {

    const val EMPTY_STRING = ""
    const val SPACE = " "
    const val YOUTUBE = "YouTube"
}