package com.example.compmoviedb.domain.models.moviedetails

data class ProductionCountryD(
    val iso_3166_1: String,
    val name: String
)