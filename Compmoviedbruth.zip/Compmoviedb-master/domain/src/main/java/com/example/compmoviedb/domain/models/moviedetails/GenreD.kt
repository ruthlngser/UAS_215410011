package com.example.compmoviedb.domain.models.moviedetails

data class GenreD(
    val id: Int,
    val name: String
)