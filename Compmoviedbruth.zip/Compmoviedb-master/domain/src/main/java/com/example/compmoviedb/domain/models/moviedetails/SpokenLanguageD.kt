package com.example.compmoviedb.domain.models.moviedetails

data class SpokenLanguageD(
    val iso_639_1: String,
    val name: String
)