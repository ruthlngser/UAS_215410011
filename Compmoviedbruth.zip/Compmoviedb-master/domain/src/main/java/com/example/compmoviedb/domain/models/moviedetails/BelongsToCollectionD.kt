package com.example.compmoviedb.domain.models.moviedetails

data class BelongsToCollectionD(
    val backdrop_path: String,
    val id: Int,
    val name: String,
    val poster_path: String
)