package com.example.compmoviedb.domain.models.moviedetails

data class ProductionCompanyD(
    val id: Int,
    val logo_path: String,
    val name: String,
    val origin_country: String
)