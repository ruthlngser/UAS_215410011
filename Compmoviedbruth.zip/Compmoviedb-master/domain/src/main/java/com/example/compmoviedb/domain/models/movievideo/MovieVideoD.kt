package com.example.compmoviedb.domain.models.movievideo

data class MovieVideoD(
    val id: Int,
    val resultMovieVideoDetailsDS: List<ResultMovieVideoDetailsD>
)