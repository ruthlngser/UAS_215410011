package com.example.compmoviedb.data.models.remote.moviedetails

data class SpokenLanguage(
    val iso_639_1: String?,
    val name: String?
)