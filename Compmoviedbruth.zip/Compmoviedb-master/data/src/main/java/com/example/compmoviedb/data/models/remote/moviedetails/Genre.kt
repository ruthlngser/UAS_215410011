package com.example.compmoviedb.data.models.remote.moviedetails

data class Genre(
    val id: Int?,
    val name: String?
)