package com.example.compmoviedb.data.models.remote.moviedetails

data class ProductionCountry(
    val iso_3166_1: String?,
    val name: String?
)