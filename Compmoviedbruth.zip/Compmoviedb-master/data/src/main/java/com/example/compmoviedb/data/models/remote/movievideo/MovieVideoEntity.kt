package com.example.compmoviedb.data.models.remote.movievideo

data class MovieVideoEntity(
    val id: Int?,
    val results: List<Result>?
)